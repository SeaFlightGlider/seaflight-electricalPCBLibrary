No Lead Packages:

*length*\_*width*\_*height*

SOIC:

*length*\_*width*\_*height*\_P*pitch*

SSOP:

*length*\_*width*\_*height*\_P*pitch*
